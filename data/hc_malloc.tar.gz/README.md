## HC_MALLOC


### General

hc_malloc is a replacement method to the classic C malloc, calloc and realloc functions.

The hc prefix alludes to the internally implemented Heap Control functionality.

---

### Install

* Download the ```hc_malloc.tar.gz``` package.
* Move the package in the desired directory.
* Un-tar ```tar -xvf hc_malloc.tar.gz```. ```hc_malloc``` directory will be created.
* Change your present working directory to the newly created ```hc_malloc``` directory: ```cd hc_malloc```.
* Run the ```install.sh``` script.
* This will compile and install the library and headers file in the appropriate locations.
* Pre-requisite to run this install is that your system needs to have ```make```, ```cmake``` and ```gcc``` commands installed.
* The test subdirectory contains a test source that can be compiled by running the ```meketest.sh``` script which will produce a ```test``` executable.
* hc_malloc directory structure:
```
hc_malloc
└── 1.0.0
    ├── LICENSE -> doc/LICENSE
    ├── README.md -> doc/README.md
    ├── VERSION
    ├── doc
    │   ├── LICENSE
    │   └── README.md
    ├── include
    │   └── hc_malloc.h
    ├── install.sh
    ├── lib
    │   └── src
    │       ├── CMakeLists.txt
    │       └── hc_malloc.c
    └── test
        ├── main.c
        └── maketest.sh
```

---

### Integration

* Add ```#include <hc_malloc.h>``` to your source.
* At the beginning of your code add the line: ```hc_init();``` to set up the heap address arena.
* When compiling include the link to the library. Example: 
```gcc -o my_program -lhc_malloc my_program.c```.

---

### Functions

* ```hc_init()``` - initialize array, capacity and next_idx in struct.
* ```hc_cleanup()``` - free all addresses in the array.
* ```hc_free(addr_pntr)``` - free and remove a pointer from array.
* ```hc_display()``` - debug/visibility routine.
* ```hc_malloc(size)```	- generate heap memory area, store and return pointer.
* ```hc_calloc(num_elem, elem_size)``` - generate initialized heap memory area.
* ```hc_realloc(old_pntr, size)```- realloc with different size and retain orig. value.
* ```hc_strdup(addr_pntr)``` - same as above, but moves content to heap pointed area.

---

### License

This code is released under a MIT License

---


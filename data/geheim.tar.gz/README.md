## GEHEIM

### General

Encryption utility that will let you obfuscate the content of a file, rendering it unable to display or otherwise render, its content.

---

### Target Platforms

* macOS
* Linux
* Unix

---

### System Requirements

* Prerequisites to build the application:
    * A ```C``` or ```C++``` compiler:
        * MacOS: ```Xcode Command Line Tools``` (provides ```clang```).
        * Linux: ```gcc``` or ```clang```.
        * Unix: ```cc``` , ```gcc``` , ```pcc``` ...
    * A native build engine / generator:
        * ```cmake```, ```make``` or ```ninja```.

---

### Install

* From the command line (Terminal) type: 
    * ```curl -L https://yveshoebeke.github.io/install/deploy_geheim.sh | sh```
* The installation will start automatically.
<br>
* If standard system directories are not writeable an attempt will be made to create the appropriate locations in the user's home directory:
    * ```HOME/.local/bin/```
    * ```HOME/.local/share/doc/geheim/```
    * ```HOME/.local/share/licenses/geheim/```
    * ```HOME/.local/share/man/```

---

### Command Options

* ```geheim [-h | -v | -o | -e] [-f target]```
* ```geheim [--help | --version | --overwrite | --encode] [--file target]```
<br>
* ```-e``` - ```--encode``` Encode (omitting will decode)
* ```-f``` - ```--file``` Target file
* ```-o``` - ```--overwrite``` Overwrite (encoding will be performed on the target file itself)
* ```-v``` - ```--version``` Version
* ```-h``` -  ```--help``` Help, shows command line options
<br>
* Option flags can be combined in a logical manner:
    * ```-eof``` Encode and overwrite the file.
    * ```-ef```  Creates file with the encoded content.
    * ```-of``` Decode and overwrite the file.
<br>
* Resulting file will have the ```geheim``` suffix attached to its name.
   * Example: ```my_document.doc``` -> ```my_document.doc.geheim```
   * If the ```-o``` flag is specified the name will not change.
* A blank return on the passcode prompt will omit the passcode process.

---

### Examples

* Encode a file: ```geheim -e -f path/to/file.ext``` 
    * Result: ```path/to/file.ext.geheim``` 
* Encode a file onto itself: ```geheim -e -o -f path/to/file.ext```
* Decode a file: ```geheim -f path/to/file.ext``` 
    * Result: ```path/to/file.ext.geheim```
* Same with a file  overwrite: ```geheim -o -f path/to/file.ext```

---

### Important Notes

* After a file was processed, the resulting file name and hash will be displayed.
* Omitting a passcode will alow anybody to correctly decode with this application.
* Not available for Microsoft Windows(tm) based systems.
* If an encoded file is decoded without the Overwrite (```-o``` / ```--overwrite```) flag, the resulting file will have the ```.geheim``` extention appended to it, so a full encode/decode cycle without using the -o flage will result in the following files being created:
    * Assume: ```filename.ext``` is the original clear file.
    * After encoding (```geheim -e -f filename.ext```): ```filename.ext.geheim``` .
    * After decoding the encoded file (```geheim -f filename.ext.geheim```): ```filename.ext.geheim.geheim``` .

---

### Test

* A test script is installed in:
    * ```HOME/.local/share/geheim/tests/test_geheim.sh```
* It will encode and then decode the test data as follows:
    * Gather the SHASUM (SHA1) from all the files in the data/ sub directory.
    * Encode each file and leave the encoded file in the directory (added extention: .geheim).
    * Decode all the encoded files back.
    * Compare the SHASUM with the original equivalent clear file.
    * Will encode and decode the clear files by overwriting them.
    * Compare the SHASUM with the original equivalent clear file.

---

### License

This code is released under a MIT License

---


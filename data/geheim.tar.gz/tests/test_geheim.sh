#!/bin/sh

GREEN=$'\033[32m'
RED=$'\033[31m'
RESET=$'\033[0m'

get_checksum() {
	local fn=$1
	echo "checkdum = $(shasum ${fn})"
}

SHASUM_FILE="clear_files.shasum"
GEHEIM_EXT="geheim"

# 1. Clean test area
rm -f data/*.geheim
rm -f "$SHASUM_FILE"

# 2. Gather checksums of data target files:
shasum data/* > "$SHASUM_FILE"

# 3. Gather test targets(in data/ sub-directory)
# Ensure the loop skips safely if no files match
shopt -s nullglob

# 4. Populate the "array" from the subdirectory
echo "\n\4{GREEN}Collecting target files (you can drop your own test files in data/ directory):"
echo "-------------------------------------------------------------------------------${RESET}"
for FILE in data/*; do
	echo "$FILE"
	# Verify it is actually a file, not a directory
	if [[ -f "$FILE" && -e "$FILE" ]]; then
		FILES="$FILES $FILE"	#files="$files#$file"
	fi
done

# 5. Encode the files (file -> file.geheim):
echo "\n${GREEN}Encode the files (filename.ext -> filename.ext.geheim):"
echo "--------------------------------------------------------${RESET}"
OLDIFS="$IFS"
IFS=" "

for FILE in $FILES; do
	yes "SomeSecretPasscode" | geheim -e -f $FILE
done

# 6. Encode the files (overwrite file -> file):
echo "\n${GREEN}Encode and Overwrite the files (filename.ext -> filename.ext):"
echo "---------------------------------------------------------------${RESET}"
OLDIFS="$IFS"
IFS=" "

for FILE in $FILES; do
	yes "SomeSecretPasscode" | geheim -o -e -f $FILE
done

# 7. Decode encoded files:
echo "\n${GREEN}Decode the Overwritten files:"
echo "------------------------------${RESET}"

for FILE in $FILES; do
	ENCODED_FILE="$FILE"
	yes "SomeSecretPasscode" | geheim -o -f $ENCODED_FILE
done

# 8. Decode encoded files (file.geheim->file.geheim.geheim):
echo "\n${GREEN}Decode the Encoded files (filename.ext.geheim -> filename.ext.geheim.geheim):"
echo "------------------------------------------------------------------------------${RESET}"

for FILE in $FILES; do
	ENCODED_FILE="$FILE.$GEHEIM_EXT"
	yes "SomeSecretPasscode" | geheim -f $ENCODED_FILE
done

# 9. Gather the checksums of the encoded->decoded files:
echo "\n${GREEN}Checking checksums of decoded (filename.ext.geheim.geheim) files with the clear files:"
echo "---------------------------------------------------------------------------------------${RESET}"

for FILE in $FILES; do
	DECODED_FILE="$FILE.$GEHEIM_EXT.$GEHEIM_EXT"
	# Extract just the hash field (removing the filename).
	LOCAL_HASH=$(shasum "$DECODED_FILE" | cut -d' ' -f1)

	# Check if the hash exists in the clear_files.shasum file.
	if grep -q "$LOCAL_HASH" clear_files.shasum; then
		echo "$DECODED_FILE: ${GREEN}OK${RESET}"
	else
		echo "$DECODED_FILE: ${RED}FAILED${RESET}"
	fi
done


# 10. Gather the checksums of the encoded->decoded files:
echo "\n${GREEN}Checking checksums of overwritten decoded files (filename.ext) with the clear files:"
echo "-------------------------------------------------------------------------------------${RESET}"

echo $(shasum -c "$SHASUM_FILE") | sed "s/OK/${GREEN}&${RESET}/g; s/FAILED/${RED}&${RESET}/g"
echo

IFS="$OLDIFS"
